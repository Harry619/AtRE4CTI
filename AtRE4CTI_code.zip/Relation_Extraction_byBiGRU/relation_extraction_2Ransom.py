import warnings

warnings.filterwarnings('ignore', category=FutureWarning)

import sys

sys.path.append('../../../../')
import utils
import os
import parseJsontoFeatures
import x2index
import prepare
import layers
import report

import argparse
from keras.models import Model
from keras.layers import Dense, Input, Embedding, Concatenate, Flatten
from keras.layers import LSTM, Bidirectional, GRU
from keras.layers import Dropout
from keras.optimizers import Adam
import pickle
from keras import backend as K


from keras_self_attention import SeqSelfAttention
import datetime
# ambiguous role choice argument
ArgumentList3 = [
    "Organization", "Device", "Person", "Software", "System", "Website",
    "File", "Version", "O", "Money", "Number"
]


def process_input_phrase(fname):
    """ label file split into data and label """
    content = utils.readFileEncode(fname, 'utf8')
    lines = content.split('\n')[:-1]

    sentences, phrases, labels = [], [], []
    phrase, label, text = {}, [], []
    oldtype, oldoffset, firstoffset, thislabel, thisrole = '', 0, 0, 0, ''
    for i in range(len(lines)):
        if len(lines[i]) > 3:
            words = lines[i].split('\t')
            # select only samples that were labeled as in ArgumentList3

            if words[2][2:] in ArgumentList3:
                if words[2].startswith('B-'):
                    if text:
                        phrase={'surface':" ".join(text),'entitylabel':thislabel,'headentity':text[-1],\
                                'offset':oldoffset,'firstoffset':firstoffset}
                        phrases.append(phrase)
                        label.append(thisrole)
                    text = []
                    text.append(words[0])
                    firstoffset = int(words[1])
                    thislabel = words[2][2:]
                    thisrole = words[3][2:]
                elif words[2].startswith('I-'):
                    if words[2][2:] == oldtype[2:]:
                        text.append(words[0])
                    elif words[2][2:] != oldtype[2:]:
                        if text:
                            phrase={'surface':" ".join(text),'entitylabel':thislabel,'headentity':text[-1], \
                                    'offset':oldoffset,'firstoffset':firstoffset}
                            phrases.append(phrase)
                            label.append(thisrole)
                        text = []
                        text.append(words[0])
                        firstoffset = int(words[1])
                        thislabel = words[2][2:]
                        thisrole = words[3][2:]
                oldoffset = int(words[1])
            oldtype = words[2]

        else:
            if text:
                phrase={'surface':" ".join(text),'entitylabel':thislabel,'headentity':text[-1], \
                        'offset':oldoffset,'firstoffset':firstoffset}
                phrases.append(phrase)
                label.append(thisrole)
                text = []

            if len(phrases) > 0 and len(label) > 0:
                sentences.append(phrases)
                labels.append(label)
                phrases = []
                label = []
            elif len(phrases) == 0 and i < len(lines) - 1:
                sentences.append([])
                labels.append([])

    return sentences, labels


def build_model(allidx, MAX_LENGTH, classweight):
    """ build model for event detection task
    Input:  allidx-dict of index of word, label, features, extra features
                MAX_LENGTH-length of sentence
                classweight-weight by frequency for each class
                flags-collection of flags (use/not use) for feature sets
        Output: model and print out model summary
    """
    wordidx, roleidx, featuresidx = allidx
    main_input = Input(shape=(MAX_LENGTH, ), name='main_input', dtype='int32')
    inputNodes = [main_input]

    # w2vmodel = "../embeddings/Domain-Word2vec.model"
    w2vmodel = "../embeddings/(Cyber-Word2Vec)1million.word2vec.model"
    embedding_matrix, EMBEDDING_DIM, vocabulary_size = prepare.wv_embedded(
        wordidx, w2vmodel)

    print('=====')
    print('embedding_matrix',embedding_matrix)
    print('=====')
    print('EMBEDDING_DIM',EMBEDDING_DIM)
    print('=====')
    print('vocabulary_size',vocabulary_size)
    print('=====')


    x = Embedding(output_dim=EMBEDDING_DIM,
                  weights=[embedding_matrix],
                  input_dim=vocabulary_size,
                  input_length=MAX_LENGTH,
                  mask_zero=True)(main_input)

    numnode = int(EMBEDDING_DIM / 2)

    neridx, subneridx, argsidx, distanceidx, wikineridx, dbpedianeridx, passiveidx, posidx = featuresidx

    x = Dense(numnode)(x)
    x = Dropout(0.3)(x)
    numnode = int(numnode / 2)
    x = Dense(numnode)(x)
    x = Dropout(0.3)(x)
    numnode = int(numnode / 2)
    x = layers.NonMasking()(x)
    x = Flatten()(x)

    inputNodes, distfromtrigger_layer = layers.embedlayer(
        inputNodes=inputNodes,
        layername="distfromtrigger_input",
        x_idx=distanceidx,
        MAX_LENGTH=1)
    distfromtrigger_layer = layers.NonMasking()(distfromtrigger_layer)
    distfromtrigger_layer = Flatten()(distfromtrigger_layer)
    x = Concatenate()([x, distfromtrigger_layer])
    numnode += int(len(distanceidx) / 2)

    inputNodes, leftargument_layer = layers.embedlayer(
        inputNodes=inputNodes,
        layername="leftargument_input",
        x_idx=argsidx,
        MAX_LENGTH=1)
    leftargument_layer = layers.NonMasking()(leftargument_layer)
    leftargument_layer = Flatten()(leftargument_layer)
    x = Concatenate()([x, leftargument_layer])
    numnode += int(len(argsidx) / 2)

    inputNodes, rightargument_layer = layers.embedlayer(
        inputNodes=inputNodes,
        layername="rightargument_input",
        x_idx=argsidx,
        MAX_LENGTH=1)
    rightargument_layer = layers.NonMasking()(rightargument_layer)
    rightargument_layer = Flatten()(rightargument_layer)
    x = Concatenate()([x, rightargument_layer])
    numnode += int(len(argsidx) / 2)

    inputNodes, ner_layer = layers.embedlayer(inputNodes=inputNodes,
                                              layername="ner_input",
                                              x_idx=neridx,
                                              MAX_LENGTH=1)
    ner_layer = layers.NonMasking()(ner_layer)
    ner_layer = Flatten()(ner_layer)
    x = Concatenate()([x, ner_layer])
    numnode += int(len(neridx) / 2)

    inputNodes, wikiner_layer = layers.embedlayer(inputNodes=inputNodes,
                                                  layername="wikiner_input",
                                                  x_idx=wikineridx,
                                                  MAX_LENGTH=1)
    wikiner_layer = layers.NonMasking()(wikiner_layer)
    wikiner_layer = Flatten()(wikiner_layer)
    x = Concatenate()([x, wikiner_layer])
    numnode += int(len(wikineridx) / 2)

    inputNodes, dbpedianer_layer = layers.embedlayer(
        inputNodes=inputNodes,
        layername="dbpedianer_input",
        x_idx=dbpedianeridx,
        MAX_LENGTH=1)
    dbpedianer_layer = layers.NonMasking()(dbpedianer_layer)
    dbpedianer_layer = Flatten()(dbpedianer_layer)
    x = Concatenate()([x, dbpedianer_layer])
    numnode += int(len(dbpedianeridx) / 2)

    inputNodes, arg_layer = layers.embedlayer(inputNodes=inputNodes,
                                              layername="entitylabel_input",
                                              x_idx=argsidx,
                                              MAX_LENGTH=1)
    arg_layer = layers.NonMasking()(arg_layer)
    arg_layer = Flatten()(arg_layer)
    x = Concatenate()([x, arg_layer])
    numnode += int(len(argsidx) / 2)

    inputNodes, subner_layer = layers.embedlayer(inputNodes=inputNodes,
                                                 layername="finerner_input",
                                                 x_idx=subneridx,
                                                 MAX_LENGTH=1)
    subner_layer = layers.NonMasking()(subner_layer)
    subner_layer = Flatten()(subner_layer)
    x = Concatenate()([x, subner_layer])
    numnode += int(len(subneridx) / 2)

    numnode = int((numnode + len(roleidx)) * 2 / 3)
    x = layers.Lambda(lambda x: K.expand_dims(x, axis=-1))(x)
    # lstm_out = Bidirectional(LSTM(numnode, dropout=0.3,  # 0.3,
    #                               return_sequences=True))(x)
    # # numnode = int((numnode + len(labelidx)) * 2 / 3)
    # lstm_out = SeqSelfAttention(attention_activation='relu',
    #                             attention_width=5)(lstm_out)
    # lstm_out = Flatten()(lstm_out)

    # Encoder GRU
    encoder_gru = Bidirectional(GRU(numnode, return_sequences=True, return_state=True, name='encoder_gru'),
                                name='bidirectional_encoder')
    encoder_out, encoder_fwd_state, encoder_back_state = encoder_gru(x)

    # Set up the decoder GRU, using `encoder_states` as initial state.
    decoder_gru = GRU(numnode * 2, return_sequences=True, return_state=True, name='decoder_gru')
    decoder_out, decoder_state = decoder_gru(
        x, initial_state=Concatenate(axis=-1)([encoder_fwd_state, encoder_back_state])
    )
    print('encoder_out:', encoder_out,'\n','encoder_shape',encoder_out.shape)
    print('###########################')
    print('decoder_out:', decoder_out,'\n','decoder_shape',decoder_out.shape)
    print('###########################')

    decoder_concat_input = Concatenate()([encoder_out, decoder_out])
    attn_out = SeqSelfAttention(attention_activation='relu',
                                attention_width=5)(decoder_concat_input)
    decoder_concat_input = Flatten()(attn_out)
    x = Dense(numnode, activation='relu')(decoder_concat_input)
    x = Dropout(0.3)(x)
    main_output = Dense(len(roleidx), activation='softmax')(x)
    loss = layers.WeightedCategoricalCrossEntropy(classweight)
    acc = ['accuracy']

    model = Model(inputs=inputNodes, outputs=main_output)
    model.compile(loss=loss, optimizer=Adam(0.00022), metrics=acc)
    model.summary()

    return model


parser = argparse.ArgumentParser()
parser.add_argument(
    "-trainfile",
    # default="../data/train_file_copy",
    default="../data/train_file_copy",
    help="train file list",
)
parser.add_argument(
    "-testfile",
    default="../data/test_file",        # 真实测试数据集
    # default="../data/alldata_file",        # 收集所有数据集（训练集+测试集）上的关系数据
    # default="../data/alldata_file",  # 收集所有数据集（训练集+测试集）上的关系数据

    help="test file list",
)
parser.add_argument(
    "-directory",
    default="../data/content/",
    help="directory contained train and test files",
)
parser.add_argument("-epochs",
                    default=5000,
                    help="maximum number of epochs for training",
                    type=int)
parser.add_argument(
    "-eventtype",
    default="Ransom",
    help="pick a choice of eventtype, whole means choose all events",
    choices=[
        'Databreach', 'Phishing', 'Ransom', 'DiscoverVulnerability',
        'PatchVulnerability', 'whole'
    ])
parser.add_argument("-outputfile",
                    default="../data/label/BiGRU_"+"Ransom"+"_relation_m1",
                    help="specify output predict file name")


def main(argv):
    args = parser.parse_args()

    etype = []
    if args.eventtype == 'whole':
        etype = etype + [
            'PatchVulnerability', 'DiscoverVulnerability', 'Ransom',
            'Databreach', 'Phishing'
        ]
    else:
        etype.append(args.eventtype)
        # etype = etype + ['Databreach']

    filechange_position = {}
    if args.trainfile != '' and args.testfile != '':
        # ## read train file ###
        lines = utils.readFile(args.trainfile)
        listfile = lines.split('\n')[:-1]
        trainset = []
        train_labels = []
        for fname in listfile:
            filename = args.directory + fname + '.content.nostop.label'
            fsentences, flabels = process_input_phrase(filename)
            jfile = fname + '.content.json'
            jfile = os.path.join(args.directory, jfile)
            if os.path.isfile(jfile):
                each_sent_feature = parseJsontoFeatures.parse(
                    jfile, filename, 'role')
            else:
                print('no content.json file', jfile)
                continue

            trainset, train_labels = prepare.features_role_phrase(
                fsentences, each_sent_feature, trainset, etype, flabels,
                train_labels)

        # ## read test files ###
        lines = utils.readFile(args.testfile)
        listfile = lines.split('\n')[:-1]
        testset = []
        test_labels = []
        fileth = 0
        for fname in listfile:
            filechange_position[fileth] = {}
            filechange_position[fileth]['position'] = len(testset)
            filechange_position[fileth]['filename'] = fname
            fileth += 1
            filename = args.directory + fname + '.content.nostop.label'
            fsentences, flabels = process_input_phrase(filename)
            jfile = fname + '.content.json'
            jfile = os.path.join(args.directory, jfile)
            if os.path.isfile(jfile):
                each_sent_feature = parseJsontoFeatures.parse(
                    jfile, filename, 'role')
            else:
                print('no content.json file', jfile)
                continue

            testset, test_labels = prepare.features_role_phrase(
                fsentences, each_sent_feature, testset, etype, flabels,
                test_labels)

        wordidx, MAX_LENGTH = x2index.phrase2word2idx(trainset)  # input
        labelidx = x2index.role2idx(train_labels)  # output

        passiveidx = x2index.passive2idx()
        distanceidx = x2index.distance2idx()
        argsidx = x2index.args2idx(ArgumentList3)
        neridx = x2index.ner2idx(trainset)
        wikineridx = x2index.wikiner2idx(trainset)
        dbpedianeridx = x2index.dbpedianer2idx(trainset)
        subneridx = x2index.subner2idx(trainset)
        posidx = x2index.pos2idx(trainset)

        featuresidx = (neridx, subneridx, argsidx, distanceidx, wikineridx,
                       dbpedianeridx, passiveidx, posidx)

        train_X, test_X, train_features, test_features, train_y, test_y = x2index.sampleRolePhrase2idx(
            trainset, testset, train_labels, test_labels, wordidx, labelidx,
            featuresidx)

        # ## count frequency for each role for classweight ###
        classweight = {}
        freqeach = {}
        for x in labelidx.keys():
            freqeach[labelidx[x]] = 0
        for x in train_y:
            freqeach[x] += 1
        for x in labelidx.keys():
            if freqeach[labelidx[x]] == 0:
                classweight[labelidx[x]] = 0.001
            else:
                classweight[labelidx[x]] = 1.0 / float(freqeach[labelidx[x]])
        allidx = wordidx, labelidx, featuresidx

        # ## call neural ###
        train_mat, test_mat, train_y, test_y = prepare.mat_phrase(
            train_X, test_X, train_features, test_features, train_y, test_y,
            MAX_LENGTH)

        print("=====")
        print("MaxLength: ", MAX_LENGTH)
        print("=====")

        print("**************")
        print('train_mat:', train_mat)
        print("**************")
        print('train_y:', layers.to_categorical_sentence(train_y, len(labelidx)))
        print("**************")

        model = build_model(allidx, MAX_LENGTH, classweight)
        model.fit(train_mat,
                  layers.to_categorical_sentence(train_y, len(labelidx)),
                  batch_size=32,
                  epochs=args.epochs,
                  verbose=2,
                  validation_split=0.2,
                  shuffle=True)

        modelname = "../model/BiGRU_relation_" + args.eventtype + ".h5"
        model.save(modelname)
        classweightname = "../model/BiGRU_relation_classweight_" + args.eventtype + ".pkl"
        pickle.dump(classweight, open(classweightname, 'wb'))
        labelname = "../model/BiGRU_relation_label_" + args.eventtype + '.pkl'
        pickle.dump(labelidx, open(labelname, 'wb'))
        wordname = "../model/BiGRU_relation_word_" + args.eventtype + '.pkl'
        pickle.dump(wordidx, open(wordname, 'wb'))
        featurename = "../model/BiGRU_relation_feature_" + args.eventtype + '.pkl'
        pickle.dump(featuresidx, open(featurename, 'wb'))

        y_pred = model.predict(test_mat)
        scores = model.evaluate(
            test_mat, layers.to_categorical_sentence(test_y, len(labelidx)))
        # print(model.metrics_names)
        # print("==>")
        # print(scores)
        print("{}:{}".format(model.metrics_names[1], scores[1] * 100))
        y_classes = y_pred.argmax(axis=-1)

        report.classification_multilabel_oneoutput(labelidx, test_y, y_classes)
        report.to_file_oneinoneout(args.outputfile, wordidx, labelidx, y_pred,
                                   filechange_position, testset, test_y,
                                   y_classes)

        print("{}:{}".format(model.metrics_names[1], scores[1] * 100))
    print(datetime.datetime.now())


if __name__ == "__main__":
    main(sys.argv[1:])
