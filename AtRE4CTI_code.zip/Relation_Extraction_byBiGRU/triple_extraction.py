eventtype = "Databreach"
postive_sample_list = []
negative_sample_list = []

with open("../data/label/"+eventtype+"_role_m1","r",encoding='utf8') as f:
    text = f.read()
    lines = text.strip(' ').split('\n')
    for _ in lines:
        if len(_.split('\t')) > 3:
            file_index, text_word, offsetindex, true_label, pred_label = \
            _.split('\t')
            if true_label == pred_label:
                postive_role_triple = (eventtype, true_label, text_word)
                postive_sample_list.append(postive_role_triple)
            else:
                negative_role_triple = (eventtype, true_label, text_word)
                negative_sample_list.append(negative_role_triple)

with open("../data/RE_Data/" + eventtype + "_relation_triple","w",encoding='utf8') as f:
    for _ in postive_sample_list:
        f.write(_+'\n')
    f.write("###############")
    for _ in negative_sample_list:
        f.write(_+'\n')